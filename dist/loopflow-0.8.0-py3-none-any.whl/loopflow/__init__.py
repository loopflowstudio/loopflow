from __future__ import annotations

from typing import Optional

from .client import Client
from .errors import LoopflowError, WaveAlreadyRunning
from .models import PullRequest, Stimulus, Wave, WaveRun

_default_client: Optional[Client] = None


def _client() -> Client:
    global _default_client
    if _default_client is None:
        _default_client = Client()
    return _default_client


def health() -> dict:
    return _client().health()


def status() -> dict:
    return _client().status()


def waves(repo: Optional[str] = None) -> list[Wave]:
    return _client().waves(repo=repo)


def wave(name_or_id: str) -> Optional[Wave]:
    return _client().wave(name_or_id)


def create_wave(
    name: str,
    repo: str,
    flow: Optional[str] = None,
    direction: Optional[list[str]] = None,
    area: Optional[list[str]] = None,
) -> Wave:
    return _client().create_wave(name, repo, flow=flow, direction=direction, area=area)


def update_wave(
    name_or_id: str,
    flow: Optional[str] = None,
    direction: Optional[list[str]] = None,
    area: Optional[list[str]] = None,
    stimulus: Optional[Stimulus] = None,
    status: Optional[str] = None,
) -> Wave:
    return _client().update_wave(
        name_or_id,
        flow=flow,
        direction=direction,
        area=area,
        stimulus=stimulus,
        status=status,
    )


def delete_wave(name_or_id: str) -> None:
    _client().delete_wave(name_or_id)


def run_wave(
    name_or_id: str,
    flow: Optional[str] = None,
    direction: Optional[list[str]] = None,
    area: Optional[list[str]] = None,
    stimulus: Optional[Stimulus] = None,
) -> dict:
    return _client().run_wave(
        name_or_id,
        flow=flow,
        direction=direction,
        area=area,
        stimulus=stimulus,
    )


def stop_wave(name_or_id: str) -> dict:
    return _client().stop_wave(name_or_id)


def land_wave(
    name_or_id: str,
    strict: Optional[bool] = None,
    local: Optional[bool] = None,
    create_pr: Optional[bool] = None,
    worktree: Optional[str] = None,
    lint: Optional[bool] = None,
) -> dict:
    return _client().land_wave(
        name_or_id,
        strict=strict,
        local=local,
        create_pr=create_pr,
        worktree=worktree,
        lint=lint,
    )


def wave_runs(
    wave_id: Optional[str] = None,
    repo: Optional[str] = None,
    limit: Optional[int] = None,
) -> list[WaveRun]:
    return _client().wave_runs(wave_id=wave_id, repo=repo, limit=limit)


def land(name_or_id: str) -> dict:
    return _client().land_wave(name_or_id)


def wave_logs(name_or_id: str):
    return _client().wave_logs(name_or_id)


__all__ = [
    "Client",
    "LoopflowError",
    "WaveAlreadyRunning",
    "PullRequest",
    "Stimulus",
    "Wave",
    "WaveRun",
    "health",
    "status",
    "waves",
    "wave",
    "create_wave",
    "update_wave",
    "delete_wave",
    "run_wave",
    "stop_wave",
    "land_wave",
    "land",
    "wave_runs",
    "wave_logs",
]
