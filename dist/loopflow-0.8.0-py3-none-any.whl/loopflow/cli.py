from __future__ import annotations

import json
from typing import Optional

import typer

import loopflow
from loopflow.errors import LoopflowError


app = typer.Typer(help="Query lfd and manage waves.")


def _format_table(headers: list[str], rows: list[list[str]]) -> str:
    widths = [len(header) for header in headers]
    for row in rows:
        for index, cell in enumerate(row):
            widths[index] = max(widths[index], len(cell))

    def format_row(items: list[str]) -> str:
        return "  ".join(item.ljust(widths[index]) for index, item in enumerate(items))

    lines = [format_row(headers), format_row(["-" * w for w in widths])]
    lines.extend(format_row(row) for row in rows)
    return "\n".join(lines)


def _wave_rows(waves: list[loopflow.Wave]) -> list[list[str]]:
    rows: list[list[str]] = []
    for wave in waves:
        rows.append(
            [
                wave.name,
                wave.status,
                wave.flow,
                str(wave.iteration),
                wave.repo,
            ]
        )
    return rows


@app.callback(invoke_without_command=True)
def main(ctx: typer.Context, json_output: bool = typer.Option(False, "--json", "-j")) -> None:
    if ctx.invoked_subcommand is not None:
        return

    status = loopflow.status()
    waves = loopflow.waves()
    if json_output:
        typer.echo(json.dumps({"status": status, "waves": [w.model_dump() for w in waves]}, indent=2))
        return

    typer.echo(f"lfd pid={status.get('pid', 'unknown')} waves={status.get('waves_defined', 0)} running={status.get('waves_running', 0)}")
    if waves:
        typer.echo(_format_table(["name", "status", "flow", "iter", "repo"], _wave_rows(waves)))
    else:
        typer.echo("no waves")


@app.command("list")
def list_waves(
    repo: Optional[str] = None,
    json_output: bool = typer.Option(False, "--json", "-j"),
) -> None:
    waves = loopflow.waves(repo=repo)
    if json_output:
        typer.echo(json.dumps([wave.model_dump() for wave in waves], indent=2))
        return
    if waves:
        typer.echo(_format_table(["name", "status", "flow", "iter", "repo"], _wave_rows(waves)))
    else:
        typer.echo("no waves")


@app.command("show")
def show_wave(name_or_id: str, json_output: bool = typer.Option(False, "--json", "-j")) -> None:
    wave = loopflow.wave(name_or_id)
    if wave is None:
        raise typer.Exit(code=1)
    if json_output:
        typer.echo(json.dumps(wave.model_dump(), indent=2))
        return

    data = wave.model_dump()
    for key in ("id", "name", "status", "flow", "repo", "iteration"):
        if key in data:
            typer.echo(f"{key}: {data[key]}")
    if wave.active_run:
        typer.echo("active_run:")
        typer.echo(f"  id: {wave.active_run.id}")
        typer.echo(f"  status: {wave.active_run.status}")
        typer.echo(f"  iteration: {wave.active_run.iteration}")


@app.command("create")
def create_wave(
    name: str,
    repo: str,
    flow: Optional[str] = None,
    direction: Optional[list[str]] = typer.Option(None, "--direction", "-d"),
    area: Optional[list[str]] = typer.Option(None, "--area", "-a"),
) -> None:
    wave = loopflow.create_wave(name, repo, flow=flow, direction=direction, area=area)
    typer.echo(json.dumps(wave.model_dump(), indent=2))


@app.command("run")
def run_wave(name_or_id: str) -> None:
    loopflow.run_wave(name_or_id)


@app.command("stop")
def stop_wave(name_or_id: str) -> None:
    loopflow.stop_wave(name_or_id)


@app.command("delete")
def delete_wave(name_or_id: str) -> None:
    loopflow.delete_wave(name_or_id)


@app.command("land")
def land_wave(name_or_id: str) -> None:
    loopflow.land_wave(name_or_id)


@app.command("logs")
def logs_wave(name_or_id: str) -> None:
    try:
        for line in loopflow.wave_logs(name_or_id):
            typer.echo(line)
    except LoopflowError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(code=1) from exc
