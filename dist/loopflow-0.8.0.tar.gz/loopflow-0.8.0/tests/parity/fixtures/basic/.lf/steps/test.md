Test step content.
