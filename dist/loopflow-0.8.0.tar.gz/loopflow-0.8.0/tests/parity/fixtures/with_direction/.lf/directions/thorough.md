Be thorough.
