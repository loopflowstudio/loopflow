import json
import statistics
from pathlib import Path

root=Path('/tmp/subscription-measure-20261109')
def cpu(p): return p['user_ms']+p['system_ms']
def stats(v):return {'n':len(v),'median':statistics.median(v),'min':min(v),'max':max(v)}
rows=[]
for directory in ('session-baseline','process-pilot','task-calibration2','task-same-pilot','task-distinct-pilot'):
    groups={}
    for p in sorted((root/directory).glob('[0-9]*.json')):
        if any(x in p.name for x in ('.reading.','.fixture.','.partial.')):continue
        d=json.loads(p.read_text()); groups.setdefault(d['count'],[]).append((p,d))
    for n,samples in sorted(groups.items()):
        row=dict(workload=directory,count=n,n=len(samples),files=[str(p) for p,d in samples])
        row['phases']={}
        for name in samples[0][1]['phases']:
            phase=[d['phases'][name] for p,d in samples]
            row['phases'][name]=dict(cpu_ms=stats([cpu(v) for v in phase]),child_cpu_ms=stats([v['child_user_ms']+v['child_system_ms'] for v in phase]),wall_ms=stats([v['elapsed_ms'] for v in phase]),driver_cpu_ms=stats([v['driver_cpu_ms'] for v in phase]),projections=stats([v['stages'].get('projection',{}).get('count',0) for v in phase]),opens=stats([v['opens'] for v in phase]),sql=stats([v['statements'] for v in phase]),vm=stats([v['vm_steps'] for v in phase]))
        row['cycle_cpu_ms']=stats([sum(cpu(d['phases'][k]) for k in ('admission_checkpoint','cleanup','after_cleanup','late_cleanup')) for p,d in samples])
        row['cycle_without_tail_cpu_ms']=stats([sum(cpu(d['phases'][k]) for k in ('admission_checkpoint','cleanup')) for p,d in samples])
        row['initial_last_reading_ms']=stats([max(r['ms'] for r in d['admission_ms'][2:2+2*n] if r['kind']=='reading') for p,d in samples])
        row['checkpoint_last_ms']=stats([max(d['checkpoint_ms'][1:]) for p,d in samples])
        row['active_frames']=[d['windows']['active']['frames'] for p,d in samples]
        row['quiet_frames']=[d['windows']['quiet']['frames'] for p,d in samples]
        row['writer_cpu_ms']=stats([d['windows']['active']['writes'][-1]['recording_api_cpu_ms'] for p,d in samples])
        row['runtime_ms_each']=stats([cpu(d['phases']['runtime_only32'])/32 for p,d in samples])
        row['resources']=[d['resources'] for p,d in samples]
        row['balanced']=all(d['after_shutdown']['opens']==d['after_shutdown']['closes'] and d['after_shutdown']['stages']['runtime_build']['count']==d['after_shutdown']['stages']['runtime_drop']['count']==d['after_shutdown']['stages']['wake_thread_lifetime']['count'] and d['after_shutdown']['stages']['runtime_thread_start']['count']==d['after_shutdown']['stages']['runtime_thread_stop']['count'] for p,d in samples)
        row['errors']=sum(d['errors'] for p,d in samples)
        rows.append(row)
(root/'focus-summary.json').write_text(json.dumps(rows,indent=2)+'\n')
for r in rows:
 print(r['workload'],r['count'],'n',r['n'],'cycle',r['cycle_cpu_ms'],'active',r['phases']['active']['cpu_ms'],'tail',r['phases']['after_cleanup']['cpu_ms'],'balanced',r['balanced'])
