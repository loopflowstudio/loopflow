"""Private fixture enrichment and output checks, never installed state."""
import hashlib
import json
import os
import sqlite3
import subprocess
import time
from pathlib import Path


def seed_tasks(home):
    repo = (home / 'repo').resolve()
    env = {k:v for k,v in os.environ.items() if not k.startswith('LF_')}
    env.update(HOME=str(home),GIT_CONFIG_GLOBAL=os.devnull,GIT_CONFIG_NOSYSTEM='1')
    def git(*args):
        return subprocess.check_output(['git','-C',str(repo),*args],env=env,stdin=subprocess.DEVNULL,stderr=subprocess.STDOUT,text=True).strip()
    git('-c','user.name=Fixture','-c','user.email=fixture@example.invalid','commit','--allow-empty','-qm','Fixture base')
    base = git('rev-parse','HEAD')
    c = sqlite3.connect(home / 'loopflow.db')
    c.execute('PRAGMA foreign_keys=ON')
    tasks = c.execute('SELECT id,issue_identifier FROM tasks ORDER BY issue_title LIMIT 16').fetchall()
    graphs = c.execute('SELECT lf_process_id,compiled FROM graph_processes ORDER BY lf_process_id').fetchall()
    manifest = []
    for i,(task,identifier) in enumerate(tasks):
        path = home / f'checkout-{i:02}'
        branch = f'fixture-{i:02}'
        git('worktree','add','-qb',branch,str(path))
        path = str(path.resolve())
        c.execute('UPDATE tasks SET worktree=?,workspace_slug=?,branch=?,base_commit=?,primary_session_id=?,checkout_machine_id=(SELECT id FROM machines WHERE is_local=1) WHERE id=?',(path,branch,branch,base,f'session-{i:03}',task))
        c.execute('UPDATE agent_sessions SET cwd=? WHERE id=?',(path,f'session-{i:03}'))
        own = graphs[2*i:2*i+2]
        for graph,_ in own:
            c.execute('UPDATE processes SET cwd=? WHERE id=?',(path,graph))
        c.execute('INSERT INTO task_graphs(task_id,graph,step,updated_at) VALUES(?,?,?,?)',(task,json.dumps(dict(name='history',steps=[{'Skill':dict(skill=dict(name='gate'),id=None,interactive=False,interactive_name=None,returns=None,sources=[])}])),'end',int(time.time())))
        manifest.append(dict(id=task,identifier=identifier,worktree=path,graphs=[x[0] for x in own],session=f'session-{i:03}'))
    c.commit()
    assert not c.execute('PRAGMA foreign_key_check').fetchall()
    c.close()
    return manifest


def validate(body, kind, item=None):
    if kind.startswith('task'):
        assert body['task']['id'] == item['id'], body
        assert body['task']['worktree'] == item['worktree'], body
        assert len(body['graph_processes']) == 2, body
        assert body['overview'] is not None and body['row'] is not None, body
        assert body['overview']['graph'] is not None, body
    else:
        assert body['nodes'], body
        assert any(row['kind'] == 'agent_process' for row in body['nodes']), body


def digest(body):
    return hashlib.sha256(json.dumps(body,sort_keys=True).encode()).hexdigest()


def change_task(home, item):
    start=time.process_time()
    with sqlite3.connect(home/'loopflow.db') as c:
        c.execute('UPDATE tasks SET issue_title=? WHERE id=?',('Changed task by fixture',item['id']))
    return dict(driver_writer_cpu_ms=(time.process_time()-start)*1000)
