"""Separate profiles only: wrap frozen drivers without changing timing samples."""
import importlib.util
import json
import os
import subprocess
import sys
import time
from pathlib import Path

source, prefix, *arguments = sys.argv[1:]
module_spec = importlib.util.spec_from_file_location('frozen', source)
m = importlib.util.module_from_spec(module_spec)
module_spec.loader.exec_module(m)
original_popen = subprocess.Popen
pid = None
profilers = []


def popen(args, *a, **kw):
    global pid
    p = original_popen(args, *a, **kw)
    if 'server::service::subscription_measurement::subscription_server' in args:
        pid = p.pid
    return p


subprocess.Popen = popen
phase = m._phase
trace = []


def profile_phase(control, results, name, run):
    if name in os.environ.get('PROFILE_PHASES','cleanup').split(','):
        profiler = original_popen(['/usr/bin/sample',str(pid),'5','1','-file',f'{prefix}-{name}.sample'], stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        profilers.append(profiler)
        time.sleep(0.15)  # attach before cancellation; profile-only, excluded from timings
    if name == 'after_cleanup':
        def tail():
            began = time.monotonic()
            while time.monotonic()-began < 2.2:
                trace.append(dict(ms=(time.monotonic()-began)*1000, snapshot=m._control(control,'snapshot')))
                time.sleep(0.05)
        run = tail
    value = phase(control,results,name,run)
    if name == 'after_cleanup':
        for p in profilers:
            p.wait(timeout=15)
        profilers.clear()
        Path(prefix+'-tail.json').write_text(json.dumps(trace,indent=2))
    return value


m._phase = profile_phase
sys.argv = [source,*arguments]
try:
    m.main()
finally:
    for p in profilers:
        p.wait(timeout=15)
