"""Pair frozen focus-v1 samples without changing the workload or its imports."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('candidate', type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--rounds', type=int, default=5)
    args = parser.parse_args()
    frozen = Path('/tmp/subscription-measure-20261109')
    manifest = json.loads((frozen / 'freeze.json').read_text())
    baseline = Path(manifest['server'])
    assert digest(baseline) == manifest['server_sha256']
    for name, expected in manifest['files'].items():
        assert digest(frozen / name) == expected, name
    candidate = args.candidate.resolve()
    spec = importlib.util.spec_from_file_location('frozen_focus', frozen / 'focus-v1.py')
    workload = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(workload)
    args.output.mkdir(parents=True, exist_ok=False)
    source = [
        'rust/loopflow/src/server/subscriptions.rs',
        'rust/loopflow/src/server/service.rs',
        'rust/loopflow/src/server/subscription_measurement.rs',
        'rust/loopflow/src/performance/subscription_measurement.rs',
        'rust/loopflow/src/lf/commands/subscribe.rs',
    ]
    metadata = dict(
        baseline_freeze=manifest,
        candidate=str(candidate), candidate_sha256=digest(candidate),
        candidate_revision=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
        candidate_sources={p: digest(Path(p)) for p in source},
        orchestrator_sha256=digest(Path(__file__)),
        workload='unchanged focus-v1._sample; defaults; 1/16 multiplexed; both cleanup tails',
        rounds=args.rounds,
    )
    (args.output / 'metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
    for repeat in range(args.rounds):
        reverse = repeat % 2 == 1
        shapes = [16, 1] if reverse else [1, 16]
        order = [('baseline', baseline), ('candidate', candidate)]
        if reverse:
            order.reverse()
        for count in shapes:
            for label, binary in order:
                name = f'{repeat + 1}-{count}-{label}'
                print(f'Starting {name}', flush=True)
                workload._sample(binary, args.output / f'{name}.json', count, False, reverse, False, True)
                print(f'Passed {name}', flush=True)


if __name__ == '__main__':
    main()
