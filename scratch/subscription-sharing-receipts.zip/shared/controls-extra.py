"""Two additional distinct-Task pairs for the observed quiet CPU uncertainty."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import traceback

root=Path('/tmp/subscription-sharing-20261109')
frozen=Path('/tmp/subscription-measure-20261109')
freeze=json.loads((frozen/'freeze.json').read_text())
for name, value in freeze['files'].items():
    assert hashlib.sha256((frozen/name).read_bytes()).hexdigest()==value
baseline=Path(freeze['server'])
assert hashlib.sha256(baseline.read_bytes()).hexdigest()==freeze['server_sha256']
candidate=root/'candidate-release'
assert hashlib.sha256(candidate.read_bytes()).hexdigest()==json.loads((root/'candidate-freeze.json').read_text())['binary_sha256']
output=root/'controls'
metadata=dict(reason='All three initial distinct-Task pairs increased quiet server CPU by 21%, 71%, 57%; near-touching ranges leave a concrete regression uncertainty. Extend only this control to five pairs, retaining all original samples.',orchestrator_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rounds=[4,5],frozen=freeze)
(output/'extra-metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
sys.path.insert(0,str(frozen))
spec=importlib.util.spec_from_file_location('frozen_paths',frozen/'paths-v1.py')
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
os.environ['BENCH_KIND']='task-distinct'
for repeat in (4,5):
    reverse=repeat%2==0
    binaries=[('baseline',baseline),('candidate',candidate)]
    if reverse: binaries.reverse()
    for label,binary in binaries:
        name=f'{repeat}-task-distinct-{label}'
        target=output/(name+'.json')
        assert not target.exists()
        print('Starting '+name,flush=True)
        try:
            module._sample(binary,target,16,False,reverse,False,True)
        except Exception:
            target.with_suffix('.failure.txt').write_text(traceback.format_exc())
            raise
        print('Passed '+name,flush=True)
