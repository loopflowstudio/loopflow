"""Bounded paired controls using the unchanged frozen path workload."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import traceback

ROOT = Path('/tmp/subscription-sharing-20261109')
FROZEN = Path('/tmp/subscription-measure-20261109')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    freeze = json.loads((FROZEN / 'freeze.json').read_text())
    for name, value in freeze['files'].items():
        assert digest(FROZEN / name) == value, name
    baseline = Path(freeze['server'])
    assert digest(baseline) == freeze['server_sha256']
    candidate = ROOT / 'candidate-release'
    provenance = json.loads((ROOT / 'candidate-freeze.json').read_text())
    assert digest(candidate) == provenance['binary_sha256']
    sys.path.insert(0, str(FROZEN))
    spec = importlib.util.spec_from_file_location('frozen_paths', FROZEN / 'paths-v1.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    output = ROOT / 'controls'
    output.mkdir(exist_ok=False)
    (output / 'metadata.json').write_text(json.dumps(dict(
        baseline=freeze, candidate=provenance,
        orchestrator_sha256=digest(Path(__file__)), rounds=3,
        workload='unchanged paths-v1._sample; 16 multiplexed; normal defaults; both tails',
    ), indent=2) + '\n')
    for repeat in range(3):
        reverse = repeat % 2 == 1
        kinds = ['task-same', 'task-distinct', 'process']
        binaries = [('baseline', baseline), ('candidate', candidate)]
        if reverse:
            kinds.reverse()
            binaries.reverse()
        for kind in kinds:
            os.environ['BENCH_KIND'] = kind
            for label, binary in binaries:
                name = f'{repeat + 1}-{kind}-{label}'
                print(f'Starting {name}', flush=True)
                try:
                    module._sample(binary, output / f'{name}.json', 16, False, reverse, False, True)
                except Exception:
                    (output / f'{name}.failure.txt').write_text(traceback.format_exc())
                    raise
                print(f'Passed {name}', flush=True)


if __name__ == '__main__':
    main()
