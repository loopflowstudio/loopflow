"""One excluded Task diagnostic: native Git Trace2 and server stacks by phase."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/tmp/subscription-sharing-20261109')
FROZEN = Path('/tmp/subscription-measure-20261109')
output = ROOT / 'diagnostic'
output.mkdir(exist_ok=False)
freeze = json.loads((FROZEN / 'freeze.json').read_text())
for name, expected in freeze['files'].items():
    assert hashlib.sha256((FROZEN / name).read_bytes()).hexdigest() == expected
sys.path.insert(0, str(FROZEN))
spec = importlib.util.spec_from_file_location('frozen_paths', FROZEN / 'paths-v1.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
os.environ['BENCH_KIND'] = 'task-distinct'
os.environ['GIT_TRACE2_EVENT'] = str(output / 'git-trace.jsonl')
original_popen = subprocess.Popen
server_pid = None
profilers = []
boundaries = []


def popen(args, *a, **kw):
    global server_pid
    child = original_popen(args, *a, **kw)
    if 'server::service::subscription_measurement::subscription_server' in args:
        server_pid = child.pid
    return child


original_control = module._control


def control(peer, action, **kwargs):
    before = time.time_ns()
    result = original_control(peer, action, **kwargs)
    after = time.time_ns()
    if action in ('begin', 'end'):
        boundaries.append(dict(action=action, name=kwargs['name'], before_ns=before, after_ns=after))
        (output / 'boundaries.json').write_text(json.dumps(boundaries, indent=2))
    if action == 'begin' and kwargs['name'] in ('quiet', 'active'):
        log = (output / f"{kwargs['name']}-sample.log").open('w')
        profiler = original_popen(['/usr/bin/sample', str(server_pid), '3', '1', '-file', str(output / f"{kwargs['name']}.sample")], stdout=log, stderr=subprocess.STDOUT)
        profilers.append((profiler, log))
    return result


subprocess.Popen = popen
module._control = control
try:
    module._sample(ROOT / 'candidate-release', output / 'excluded-task-distinct.json', 16, False, False, False, True)
finally:
    statuses = []
    for profiler, log in profilers:
        statuses.append(profiler.wait(timeout=15))
        log.close()
    (output / 'metadata.json').write_text(json.dumps(dict(
        excluded_from_timings=True, server_pid=server_pid, profiler_exit_codes=statuses,
        orchestrator_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        native_git_trace=True, frozen=freeze,
    ), indent=2))
