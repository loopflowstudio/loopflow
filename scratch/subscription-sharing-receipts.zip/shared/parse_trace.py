"""Attribute native Git Trace2 starts to the excluded run's phase windows."""
from collections import Counter
from datetime import datetime
import html
import json
from pathlib import Path
import re
import sys

ROOT=Path('/tmp/subscription-sharing-20261109')
d=ROOT/(sys.argv[1] if len(sys.argv)>1 else 'diagnostic')
boundaries=json.loads((d/'boundaries.json').read_text())
windows={}
for b in boundaries:
    windows.setdefault(b['name'],{})[b['action']]=b
events=[json.loads(line) for line in (d/'git-trace.jsonl').read_text().splitlines()]
starts=[e for e in events if e['event']=='start']
exits={e['sid']:e for e in events if e['event']=='exit'}
receipt=json.loads((d/'excluded-task-distinct.json').read_text())
result={}


def epoch_ns(e):
    return int(datetime.fromisoformat(e['time'].replace('Z','+00:00')).timestamp()*1e9)


def command(e):
    args=e['argv'][1:]
    return re.sub(r'(?:/private)?/tmp/lf-subscription-[^/\s]+','<home>',' '.join(args))


for name in ('quiet','active'):
    w=windows[name]
    # Strict interior excludes control transit at either measurement boundary.
    low=w['begin']['after_ns']; high=w['end']['before_ns']
    rows=[e for e in starts if low<=epoch_ns(e)<=high]
    counts=Counter(command(e) for e in rows)
    codes=Counter(str(exits[e['sid']]['code']) if e['sid'] in exits else 'missing' for e in rows)
    phase=receipt['phases'][name]
    projections=phase['stages']['projection']['count']
    result[name]=dict(git_starts=len(rows),projections=projections,git_starts_per_projection=len(rows)/projections,commands=dict(counts),exit_codes=dict(codes),strict_start_ns=low,strict_end_ns=high)
outside=sum(not any(w['begin']['after_ns']<=epoch_ns(e)<=w['end']['before_ns'] for w in windows.values() if 'begin' in w and 'end' in w) for e in starts)
metadata=dict(excluded_from_timing=True,phases=result,total_trace_starts=len(starts),outside_all_measured_phases=outside,definition='Counts Git Trace2 start events whose wall timestamps lie strictly after begin acknowledgement and before end request. Setup/seeding and driver enrichment are outside quiet/active; ps is not Git and is outside phases. Exit-code counts are Git statuses, not fixture failures.')
(d/'attribution.json').write_text(json.dumps(metadata,indent=2)+'\n')
print(json.dumps(metadata,indent=2))
