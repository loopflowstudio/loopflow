"""Render the shared-subscription comparison from saved receipts."""
import html
import json
from pathlib import Path

ROOT=Path('/tmp/subscription-sharing-20261109')
SCRATCH=Path('/Users/jack/src/loopflow.agent/scratch')
s=json.loads((ROOT/'summary.json').read_text())
validation=json.loads((ROOT/'validation.json').read_text())
freeze=json.loads((ROOT/'candidate-freeze.json').read_text())
baseline=json.loads((ROOT/'preflight.json').read_text())


def esc(x): return html.escape(str(x))


def fmt(x):
    if x is None: return 'missing'
    return f"{x['median']:,.2f} ({x['min']:,.2f}–{x['max']:,.2f}), n={x['n']}"


def table(headers,rows):
    return '<div class="scroll"><table><thead><tr>'+''.join('<th>'+esc(h)+'</th>' for h in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+str(c)+'</td>' for c in row)+'</tr>' for row in rows)+'</tbody></table></div>'


def metric_rows(shapes,keys):
    return [(esc(name),esc(key),fmt(s[name]['baseline'].get(key)),fmt(s[name]['candidate'].get(key)),fmt(s[name]['paired_difference'].get(key))) for name in shapes for key in keys if key in s[name]['baseline'] or key in s[name]['candidate']]


def section(title,text): return '<h2>'+title+'</h2>'+text


session=[name for name in ('session-1','session-16') if name in s]
controls=[name for name in ('task-same','task-distinct','process') if name in s]
headers=('Demand','Metric','Baseline median (range)','Shared median (range)','Paired shared − baseline')
body='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Shared subscriptions — paired comparison</title>
<style>body{font:16px/1.55 system-ui,sans-serif;color:#19262c;background:#f7f7f2;max-width:1200px;margin:48px auto;padding:0 24px}h1{font-size:40px;line-height:1.12;max-width:900px}h2{margin-top:42px;font-size:24px}.verdict{border-left:5px solid #167f69;padding:14px 22px;background:#e7f1eb}table{border-collapse:collapse;width:100%;font-size:14px}th,td{text-align:left;padding:10px 12px;border-bottom:1px solid #cbd4d0;vertical-align:top}th{background:#e7ece8}.scroll{overflow:auto}small{color:#4b6267}a{color:#086f62}code,pre{font:12px/1.5 ui-monospace,monospace}pre{white-space:pre-wrap;word-break:break-word}details{margin:20px 0}td:nth-child(n+3){font-variant-numeric:tabular-nums}p{max-width:1000px}</style>
<p><small>Optimize step 4 · 2026-11-09 · release test fixtures · normal defaults</small></p>
<h1>Shared subscriptions remove duplicate reader work.</h1>'''
body+=(ROOT/'verdict.html').read_text() if (ROOT/'verdict.html').exists() else '<p class="verdict">Comparison in progress. No final verdict yet.</p>'
body+='''<p>Frozen baseline <code>17c304389</code> versus current <code>9c0b7c10b</code>, including duplicate-terminal-failure repair <code>b9b89c8e6</code>. Five alternating fresh-process pairs per Session shape, reversing binary, shape and quiet/active order. Three alternating pairs per sixteen-reader Task/Process control. The single-reader Session pairs are the primary small-demand control. No debug timings enter this report.</p>
<p>CPU means process user + system milliseconds. Quiet/active windows last approximately ten seconds. Complete-cycle CPU sums admission/first reading/checkpoint, cancellation, and both 2.2-second cleanup tails; it excludes setup, quiet/active windows and relevant-change delivery. It is not elapsed latency. Child CPU, writer CPU and Python driver CPU are separate. Resource-inventory <code>ps</code> runs outside measured phases.</p>'''
body+=section('Primary Session comparison',table(headers,metric_rows(session,['active.cpu_ms','cycle.cpu_ms','quiet.cpu_ms','first_reading_ms','checkpoint_ms','title_ms','exit_ms'])))
body+=section('Task and Process controls', '<p>Task-identical and ProcessList have three bounded pairs. Distinct Task was extended to five pairs after a quiet-CPU concern in the first three. Distinct Task demand retains sixteen different readers; identical demand can share one.</p>'+table(headers,metric_rows(controls,['cycle.cpu_ms','quiet.cpu_ms','active.cpu_ms','quiet.child_cpu_ms','active.child_cpu_ms','first_reading_ms','checkpoint_ms','title_ms','exit_ms'])))
body+=section('Work performed inside measured windows',table(headers,metric_rows(session+controls,['admission_checkpoint.projection.count','admission_checkpoint.reader_store_open.count','admission_checkpoint.runtime_build.count','admission_checkpoint.opens','quiet.projection.count','active.projection.count','active.opens','quiet.statements','active.statements','quiet.vm_steps','active.vm_steps'])))
body+=section('Cleanup tails and separated CPU',table(headers,metric_rows(session+controls,['cleanup.cpu_ms','after_cleanup.cpu_ms','late_cleanup.cpu_ms','cycle.child_cpu_ms','admission_checkpoint.child_cpu_ms','writer.cpu_ms','active.driver_cpu_ms','active.elapsed_ms'])))
body+=section('Behavior and resource release',f"<p>{validation['samples']} completed receipts; {len(validation['failures'])} failed post-processing checks. Every receipt, check and resource count is embedded below. The checks require ten retained writes, zero unwanted quiet/active frames, no SQL/projections in cleanup tails, balanced runtime/worker/connection counts, completed wake-thread lifetimes and restored warmed file descriptors. Frozen drivers also validate scoped output, independent checkpoints, relevant title updates and unrecorded fixture-process exit where applicable.</p><p>{esc(validation['normalization'])}</p><p>Close counters alone do not prove complete destruction. CPU includes both tails, final shutdown joins the server runtime, final runtime-thread counters balance, and the fixture process exits. Idle server blocking workers can remain between the drained snapshot and shutdown.</p>")
if (ROOT/'churn-summary.html').exists(): body+=section('Capped churn acceptance',(ROOT/'churn-summary.html').read_text())
if (ROOT/'diagnostic-summary.html').exists(): body+=section('Remaining limiter: distinct Task observation',(ROOT/'diagnostic-summary.html').read_text())
body+=section('Provenance and limits','''<p>The candidate was built once with the repository’s release profile (optimization level 3), then copied and hashed. The existing baseline executable was preserved and reused. The frozen driver/helper and orchestrator hashes were checked before execution. Source instrumentation, seeding, writer, probes and windows are unchanged; the fixture now passes the production shared registry to its connections. Deleted hypothetical executor tests and changed test-pause visibility do not affect this workload.</p>
<p>One busy Mac, 16 CPUs, no manufactured background load or scheduling changes. These are instrumented library test executables using production subscription dispatch, isolated stores and fixture processes. They do not measure an installed server, provider throughput, kernel wakeups or complete native/Codex orchestration. Prior forty-sample native/Codex and twenty-five-sample capped baselines remain separate. Task fixtures have completed Graph history and sixteen real isolated checkouts; live Graph transitions and larger production history remain outside this workload. No production source edits, installation, provider input, publication or landing occurred in this step.</p>
<p>Initial-reading digests and functional assertions cover the outputs the frozen drivers retain/check. They do not establish byte-identical output for every later frame. Reaped-child CPU is not a process-launch counter. The separate Trace2 diagnostic identifies Git commands; its timing is excluded.</p>''')
if (ROOT/'failures.html').exists():body+=(ROOT/'failures.html').read_text()
provenance=dict(candidate_revision=freeze['revision'],candidate_sha256=freeze['binary_sha256'],profile=freeze['build_artifact']['profile'],rustc=freeze['rustc'],baseline=baseline,orchestrators=freeze['orchestrators'],source_hashes={k:v for k,v in freeze['source_hashes'].items() if k in ['rust/loopflow/src/server/subscriptions.rs','rust/loopflow/src/server/service.rs','rust/loopflow/src/server/subscription_measurement.rs','rust/loopflow/src/performance/subscription_measurement.rs','rust/loopflow/src/lf/commands/subscribe.rs']})
for title,data in [('Build, source and driver provenance',provenance),('Every paired summary',s),('Behavior and lifecycle checks',validation),('Every complete timing receipt',json.loads((ROOT/'all-receipts.json').read_text()))]:
    body+='<details><summary>'+title+'</summary><pre>'+esc(json.dumps(data,indent=2))+'</pre></details>'
body+='''<p><a href="subscription-sharing.md">Commands and handoff</a> · <a href="subscription-sharing-receipts.zip">Receipt bundle</a> · <a href="measure.html">Measurement index</a> · <a href="subscription-followup.html">Previous default baseline</a> · <a href="subscription-measure.html">Original capped baseline</a></p><p><small>Raw artifacts: /tmp/subscription-sharing-20261109/. Original reports and binaries are retained.</small></p></html>'''
(SCRATCH/'subscription-sharing.html').write_text(body)
print('Wrote',SCRATCH/'subscription-sharing.html')
