"""Summarize retained receipts without altering any measurement workload."""
import json
from pathlib import Path
import statistics

ROOT = Path('/tmp/subscription-sharing-20261109')
CYCLE = ('admission_checkpoint', 'cleanup', 'after_cleanup', 'late_cleanup')


def stats(values):
    return dict(n=len(values), median=statistics.median(values), min=min(values), max=max(values)) if values else None


def cpu(phase, prefix=''):
    return phase[prefix+'user_ms'] + phase[prefix+'system_ms']


def metrics(row):
    result = {}
    for name, phase in row['phases'].items():
        result[name+'.cpu_ms'] = cpu(phase)
        result[name+'.child_cpu_ms'] = cpu(phase, 'child_')
        for key in ('elapsed_ms', 'driver_cpu_ms', 'statements', 'rows', 'vm_steps', 'opens', 'closes'):
            result[name+'.'+key] = phase[key]
        for key, value in phase['stages'].items():
            result[name+'.'+key+'.count'] = value['count']
    for prefix in ('', 'child_'):
        result['cycle.'+prefix+'cpu_ms'] = sum(cpu(row['phases'][p], prefix) for p in CYCLE if p in row['phases'])
    result['first_reading_ms'] = max(x['ms'] for x in row['admission_ms'][2:] if x['kind']=='reading')
    result['checkpoint_ms'] = max(row['checkpoint_ms'][1:])
    for name, times in row['changes_ms'].items():
        if isinstance(times, list): result[name+'_ms'] = max(times)
    result['writer.cpu_ms'] = row['windows']['active']['writes'][-1]['recording_api_cpu_ms']
    result['encoded_bytes'] = row['encoded_bytes']
    return result


def summarize():
    groups = {}
    receipts = {}
    for directory in ('paired', 'controls'):
        for file in (ROOT/directory).glob('*.json'):
            if file.name=='metadata.json' or file.name.count('.')!=1: continue
            row=json.loads(file.read_text())
            if 'phases' not in row: continue
            parts=file.stem.split('-')
            repeat=int(parts[0]); label=parts[-1]
            shape='session-'+str(row['count']) if directory=='paired' else '-'.join(parts[1:-1])
            receipts[str(file.relative_to(ROOT))]=row
            group=groups.setdefault(shape, {'baseline':{},'candidate':{}})
            group[label][repeat]=dict(path=str(file), values=metrics(row))
    summaries={}
    for name, group in groups.items():
        out={}
        for label, samples in group.items():
            keys=set(k for sample in samples.values() for k in sample['values'])
            out[label]={k:stats([s['values'][k] for s in samples.values() if k in s['values']]) for k in sorted(keys)}
        pairs=sorted(group['baseline'].keys() & group['candidate'].keys())
        common=set(out['baseline']) & set(out['candidate'])
        out['paired_difference']={k:stats([group['candidate'][i]['values'][k]-group['baseline'][i]['values'][k] for i in pairs]) for k in common}
        out['paired_reduction_percent']={k:stats([100*(1-group['candidate'][i]['values'][k]/group['baseline'][i]['values'][k]) for i in pairs if group['baseline'][i]['values'][k]]) for k in common}
        summaries[name]=out
    (ROOT/'summary.json').write_text(json.dumps(summaries,indent=2)+'\n')
    (ROOT/'all-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
    for name,g in summaries.items():
        print(name)
        for k in ('active.cpu_ms','quiet.cpu_ms','cycle.cpu_ms','active.child_cpu_ms','quiet.child_cpu_ms','first_reading_ms','checkpoint_ms','title_ms','exit_ms'):
            if k in g['baseline'] or k in g['candidate']:
                print(k, 'baseline',g['baseline'].get(k),'candidate',g['candidate'].get(k))


if __name__ == '__main__':
    summarize()
