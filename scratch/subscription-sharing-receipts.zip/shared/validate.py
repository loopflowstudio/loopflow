"""Post-process full retained readings and lifecycle receipts; no timed hooks."""
import hashlib
import json
from pathlib import Path
import re

ROOT=Path('/tmp/subscription-sharing-20261109')


def normalize(value, key=''):
    if isinstance(value, dict):
        return {k:normalize(v,k) for k,v in value.items()}
    if isinstance(value, list):
        items=[normalize(v) for v in value]
        if key in ('nodes','processes','graph_processes') or (items and isinstance(items[0],dict) and 'id' in items[0] and 'title' in items[0]):
            items.sort(key=lambda x:json.dumps(x,sort_keys=True))
        return items
    if value is None: return None
    if key.endswith('_at') or key in ('evidence_age_secs','pid'):
        return '<present:'+key+'>'
    if isinstance(value,str):
        value=re.sub(r'(?:/private)?/tmp/lf-subscription-[^/\s"\]]+', '<home>', value)
        value=re.sub(r'\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b','<uuid>',value)
        value=re.sub(r'\b(task|repo|home)_[0-9a-f]+\b',r'<\1-id>',value)
        if key in ('identifier','issue_identifier'): value='<task-identifier>'
        if key=='base_commit': value='<base-commit>'
    return value


def count(snapshot, name):
    return snapshot['stages'].get(name,{}).get('count',0)


def main():
    records=[]; failures=[]
    for directory in ('paired','controls','churn'):
        for file in sorted((ROOT/directory).glob('*.json')):
            if file.name=='metadata.json' or file.name.count('.')!=1: continue
            row=json.loads(file.read_text())
            if 'phases' not in row: continue
            checks={}
            if 'errors' in row:
                checks['no_reported_errors']=row['errors']==0
            else:
                log=file.with_suffix('.log').read_text()
                checks['fixture_passed']='test result: ok. 1 passed; 0 failed;' in log and 'panicked at' not in log
            checks['no_quiet_or_active_frames']=all(row['windows'][w]['frames']==0 for w in ('quiet','active'))
            writes=row['windows']['active']['writes']
            checks['ten_retained_writes']=len(writes)==10 and all(w['writes']==i and w['receipts']==i for i,w in enumerate(writes,1))
            checks['payload_retained']=writes[-1]['payload_bytes']>=2690
            for name in ('after_cleanup','late_cleanup'):
                if name in row['phases']:
                    phase=row['phases'][name]
                    checks[name+'_no_work']=phase['statements']==0 and count(phase,'projection')==0 and phase['opens']==0
            final=row['after_shutdown']
            checks['connections_balanced']=final['opens']==final['closes']
            checks['runtimes_balanced']=count(final,'runtime_build')==count(final,'runtime_drop')
            checks['runtime_threads_balanced']=count(final,'runtime_thread_start')==count(final,'runtime_thread_stop')
            checks['wake_threads_released']=count(final,'wake_thread_lifetime')==count(final,'runtime_build')
            checks['fds_restored']=row['resources']['warm']['fds']==row['resources']['drained']['fds']
            raw=json.loads(file.with_suffix('.reading.json').read_text())
            normalized=normalize(raw)
            encoded=json.dumps(normalized,sort_keys=True)
            file.with_suffix('.normalized.json').write_text(json.dumps(normalized,indent=2)+'\n')
            record=dict(path=str(file.relative_to(ROOT)),checks=checks,reported_error_count=row.get('errors'),full_initial_normalized_sha256=hashlib.sha256(encoded.encode()).hexdigest(),original_reading_digests=row['normalized_readings'],resources=row['resources'],final_counts=dict(opens=final['opens'],closes=final['closes'],stages={k:v['count'] for k,v in final['stages'].items()}))
            records.append(record)
            failures.extend((record['path'],k) for k,v in checks.items() if not v)
    result=dict(samples=len(records),failures=failures,records=records,normalization='Retains all fields and nulls; replaces fixture home paths, generated UUID/task/repo/machine identifiers, base commit, non-null timestamps/ages/PIDs; sorts inventory lists. Frozen validations independently check identity, graph count, worktree and delivery. Only the first cold full reading is retained by the frozen path driver; other initial readings have its assertions and raw per-reading digests.')
    (ROOT/'validation.json').write_text(json.dumps(result,indent=2)+'\n')
    print('Validated',len(records),'receipts; failures:',failures)
    for directory in ('paired','controls','churn'):
        digests={}
        for r in records:
            if r['path'].startswith(directory+'/'):
                digests.setdefault(r['full_initial_normalized_sha256'],[]).append(r['path'])
        print(directory,{k:len(v) for k,v in digests.items()})


if __name__=='__main__': main()
