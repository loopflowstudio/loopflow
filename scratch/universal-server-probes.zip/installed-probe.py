import hashlib
import json
import os
from pathlib import Path
import signal
import socket
import sqlite3
import subprocess
import sys
import tempfile
import time

LF = Path('/Applications/Loopflow.app/Contents/MacOS/lf')
SEED = Path('/tmp/subscription-sharing-20261109/candidate-release')
OUT = Path('/tmp/loo819-probe')
OUT.mkdir(exist_ok=True)

class Peer:
    def __init__(self, path):
        self.s = socket.socket(socket.AF_UNIX)
        self.s.settimeout(30)
        self.s.connect(str(path))
        self.f = self.s.makefile('rb')
    def send(self, value):
        self.s.sendall(json.dumps(value).encode() + b'\n')
    def read(self):
        value = json.loads(self.f.readline())
        if isinstance(value, dict) and value.get('type') == 'error':
            raise RuntimeError(value)
        return value
    def close(self):
        self.f.close()
        self.s.close()

def wait_path(path, child):
    deadline = time.monotonic() + 30
    while not path.exists():
        if child.poll() is not None or time.monotonic() > deadline:
            raise RuntimeError(f'not ready: {path}')
        time.sleep(.05)

def cpu(pid):
    value = subprocess.check_output(['ps', '-p', str(pid), '-o', 'time='], text=True).strip()
    minutes, seconds = value.split(':')
    return (int(minutes) * 60 + float(seconds)) * 1000

results = []
for count in [1, 16]:
    with tempfile.TemporaryDirectory(prefix='loo819-', dir='/tmp') as tmp:
        home = Path(tmp)
        env = {k:v for k,v in os.environ.items() if not k.startswith('LF_')}
        env.update(HOME=tmp, LF_HOME=tmp, SUBSCRIPTION_HOME=tmp, SUBSCRIPTION_DEFAULT='1', GIT_CONFIG_GLOBAL=os.devnull, GIT_CONFIG_NOSYSTEM='1')
        processes = []
        peers = []
        with (OUT / f'{count}.log').open('w') as log:
            try:
                repo=home/'repo'; repo.mkdir()
                def git(*args):
                    return subprocess.check_output(['git','-C',str(repo),*args],env=env,stderr=log,text=True).strip()
                git('init','-q')
                git('config','user.name','Fixture')
                git('config','user.email','fixture@example.invalid')
                git('commit','--allow-empty','-qm','Fixture')
                base=git('rev-parse','HEAD')
                for i in range(count):
                    subprocess.run([str(LF),'task','create','--title',f'Fixture {i}','--json'],env=env,cwd=repo,stdin=subprocess.DEVNULL,stdout=log,stderr=log,check=True,timeout=30)
                c=sqlite3.connect(home/'loopflow.db')
                rows=c.execute('SELECT id,issue_identifier FROM tasks ORDER BY issue_title').fetchall()
                tasks=[]
                for i,(id_,identifier) in enumerate(rows):
                    worktree=home/f'checkout-{i}'
                    git('worktree','add','-qb',f'fixture-{i}',str(worktree))
                    c.execute('UPDATE tasks SET worktree=?,branch=?,base_commit=?,checkout_machine_id=(SELECT id FROM machines WHERE is_local=1) WHERE id=?',(str(worktree),f'fixture-{i}',base,id_))
                    tasks.append(dict(id=id_,identifier=identifier))
                c.commit(); c.close()
                trace = OUT / f'{count}-git.jsonl'
                env['GIT_TRACE2_EVENT'] = str(trace)
                server = subprocess.Popen([str(LF), 'server', 'run'], env=env, cwd=tmp, stdin=subprocess.DEVNULL, stdout=log, stderr=log, start_new_session=True)
                processes.append(server)
                digest = hashlib.sha256(os.fsencode(home.resolve())).hexdigest()[:16]
                path = Path('/tmp') / f'lf-{os.getuid()}-{digest}' / 'machine.sock'
                wait_path(path, server)
                peer = Peer(path); peers.append(peer)
                peer.send(dict(type='hello', revision=4, min_revision=4, client=dict(kind='benchmark', platform='macos',name='loo819',version='1')))
                welcome=peer.read()
                start=time.monotonic()
                for i in range(count):
                    peer.send(dict(type='subscribe', id=str(i), operation=dict(kind='task.get',directory=str(home/'repo'),issue=tasks[i]['identifier']), select=None, resume=None))
                initial=[]
                while len(initial)<count:
                    msg=peer.read()
                    if msg['type']=='reading':
                        assert msg['frame']['unavailable'] is None, msg
                        assert msg['frame']['body']['task']['id']==tasks[int(msg['id'])]['id']
                        initial.append(msg['id'])
                setup_ms=(time.monotonic()-start)*1000
                time.sleep(3)
                trace_before=trace.stat().st_size
                before=cpu(server.pid)
                start=time.monotonic()
                time.sleep(10)
                used=cpu(server.pid)-before
                elapsed=(time.monotonic()-start)*1000
                with trace.open('rb') as f:
                    f.seek(trace_before)
                    events=[json.loads(line) for line in f if line.strip()]
                commands=[event['argv'] for event in events if event.get('event')=='start']
                result=dict(count=count, setup_ms=setup_ms, quiet_ms=elapsed, server_cpu_ms=used, git_commands=commands, welcome_build=welcome['build'],welcome_sha256=welcome['executable_sha256'],limitations='single pilot; server CPU at ps 10ms resolution excludes child CPU; current installed server and CLI-created Tasks with distinct worktrees, no Graph or Session history; one connection; no before/after claim')
                results.append(result)
                print(json.dumps({k:v for k,v in result.items() if k!='git_commands'}),flush=True)
            finally:
                for peer in peers:
                    peer.close()
                for process in reversed(processes):
                    if process.poll() is None:
                        os.killpg(process.pid, signal.SIGTERM)
                        try: process.wait(timeout=5)
                        except subprocess.TimeoutExpired:
                            os.killpg(process.pid, signal.SIGKILL)
                            process.wait()
(OUT/'results.json').write_text(json.dumps(dict(binary=str(LF),sha256=hashlib.sha256(LF.read_bytes()).hexdigest(),seed_sha256=hashlib.sha256(SEED.read_bytes()).hexdigest(),results=results),indent=2)+'\n')
